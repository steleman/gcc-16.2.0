// BEGIN PREAMBLE
.version	3.1
.target	sm_30
.address_size 64
// END PREAMBLE

// BEGIN GLOBAL FUNCTION DECL: f
.visible .func (.param.u32 %value_out) f (.param.u32 %in_ar0, .param.u32 %in_ar1);

// BEGIN GLOBAL FUNCTION DEF: f
.visible .func (.param.u32 %value_out) f (.param.u32 %in_ar0, .param.u32 %in_ar1)
{
	// [...]
	ret;
}
